package com.example;

public class Department {
	private int sno;
	private int departmentId;
	private String departmentName;

	
	public Department(int sno, int departmentId, String departmentName) {
		super();
		this.sno = sno;
		this.departmentId = departmentId;
		this.departmentName = departmentName;
	}


	@Override
	public String toString() {
		return "Department [sno=" + sno + ", departmentId=" + departmentId + ", departmentName=" + departmentName + "]";
	}
	
	
	

}
